import numpy as np
import matplotlib.pyplot as plt
import networkx as nx
import itertools
from heapq import *
from random import randint

# 找到密度计算的阈值dc
# 要求平均每个点周围距离小于dc的点的数目占总数的1%-2%
from load_graph import load_graph_noRealLable

def select_dc(dists):
    # 算法一
    N = np.shape(dists)[0]
    tt = np.reshape(dists, N * N)
    percent = 2
    position = int(N * (N - 1) * percent / 100)
    dc = np.sort(tt)[position + N]
    # 算法二
    # N=np.shape(dists)[0]
    # max_dis = np.max(dists)
    # min_dis = np.min(dists)
    # dc = (max_dis+min_dis)/2
    # while True:
    #     n_neighs = np.where(dists<dc)[0].shape[0]-N
    #     rate = n_neighs/(N*(N-1))
    #
    #     if rate>=0.01 and rate <=0.02:
    #         break
    #     if rate<0.01:
    #         min_dis = dc
    #     else:
    #         max_dis = dc
    #     dc = (max_dis + min_dis)/2
    #
    #     if max_dis + min_dis < 0.0001:
    #         break
    return dc


# 计算每个点的局部密度
def get_density(dists, dc):
    N = np.shape(dists)[0]
    rho = np.zeros(N)

    for i in range(N):
        rho[i] = np.sum(np.exp(-(dists[i, :] / dc) ** 2)) - 1
    return rho


# 对每个数据点找到密度比它大的所有点，然后再在这些点中找到距离其最近的点的距离
def get_deltas(dists, rho):
    N = np.shape(dists)[0]
    deltas = np.zeros(N)
    nearest_neiber = np.zeros(N)
    # 将密度从大到小排序
    index_rho = np.argsort(-rho)
    for i, index in enumerate(index_rho):
        # 第一个点密度最大
        if i == 0:
            continue
        # 对于其他点，则找密度比它大的点
        index_higher_rho = index_rho[:i]
        # 得到这些点到它的距离，并找到最小值
        deltas[index] = np.min(dists[index, index_higher_rho])

        # 保存最近邻点的编号
        index_nn = np.argmin(dists[index, index_higher_rho])
        nearest_neiber[index] = index_higher_rho[index_nn].astype(int)
    deltas[index_rho[0]] = np.max(deltas)
    return deltas, nearest_neiber


# 这里通过自动选取聚类中心，选取rho和deltas都大的点作为聚类中心
# 因其都为正数，这里选取rho*deltas大的数作为聚类中心
def find_centers_K(rho, deltas, K):
    rho_deltas = rho * deltas
    centers = np.argsort(-rho_deltas)
    return centers[:K]


# 通过阈值选取 rho与delta都大的点
# 作为聚类中心
def find_centers_auto(rho, deltas):
    rho_threshold = (np.min(rho) + np.max(rho)) / 2
    delta_threshold = (np.min(deltas) + np.max(deltas)) / 2
    N = np.shape(rho)[0]

    centers = []
    for i in range(N):
        if rho[i] >= rho_threshold and deltas[i] > delta_threshold:
            centers.append(i)
    return np.array(centers)


# 聚类
def cluster_DPC(rho, centers, nearest_neiber):
    K = np.shape(centers)[0]
    if K == 0:
        # print("没有发现聚类中心")
        return
    N = np.shape(rho)[0]
    labs = -1 * np.ones(N).astype(int)

    # 对聚类中心进行编号
    for i, center in enumerate(centers):
        labs[center] = i

    # 从密度大的点进行标号
    index_rho = np.argsort(-rho)
    for i, index in enumerate(index_rho):
        if labs[index] == -1:
            # 如果该点没有被标记过，我们则认为聚类标号与距离其最近且密度比它大的点是标号一样
            labs[index] = labs[int(nearest_neiber[index])]
    return labs


# 剔除离群值,是在聚类处理过后,标志为-1则为离群值
def rejectOutliers2(rho, dc, dists, centers, labs):
    N = np.shape(rho)[0]
    K = np.shape(centers)[0]
    # halo和labs一样表示每个点属于的族，初始化为-1
    halo = -1 * np.ones(N).astype(int)
    if (K > 1):
        for i in range(N):
            halo[i] = labs[i]
        for i in range(N):
            flag = False
            count1 = 0
            count2 = 0
            for j in range(N):
                if ((labs[i] == labs[j]) and (i != j)):
                    count1 = count1 + 1
                if ((labs[i] == labs[j]) and (dists[i, j] > dc) and (i != j)):
                    count2 = count2 + 1
            if (count1 == count2):
                flag = True
            if (flag):
                halo[i] = -1
    return halo


# 剔除离群值,是在聚类处理过后,标志为-1则为离群值
def rejectOutliers1(rho, dc, dists, centers, labs):
    N = np.shape(rho)[0]
    K = np.shape(centers)[0]
    # halo和labs一样表示每个点属于的族，初始化为-1
    halo = -1 * np.ones(N).astype(int)
    # bord_rho是每个族的密度边界，初始化为0
    bord_rho = np.zeros(K)
    if (K > 1):
        for i in range(N):
            halo[i] = labs[i]
            # 获取每个族的bord_rho
            for i in range(N - 1):
                for j in range(i + 1, N):
                    if ((labs[i] != labs[j]) and (dists[i, j] <= dc)):
                        rho_aver = (rho[i] + rho[j]) / 2
                        if (rho_aver > bord_rho[labs[i]]):
                            bord_rho[labs[i]] = rho_aver
                        if (rho_aver > bord_rho[labs[j]]):
                            bord_rho[labs[j]] = rho_aver
        for i in range(N):
            if (rho[i] < bord_rho[labs[i]]):
                halo[i] = -1
    return halo


# 绘制rho和deltas的图形
def draw_decision(graph, rho, deltas, name="0_decision.jpg"):
    plt.cla()
    for i in range(len(graph.nodes)):
        plt.scatter(rho[i], deltas[i], s=16., color=(0, 0, 0))
        plt.annotate(str(i), xy=(rho[i], deltas[i]), xytext=(rho[i], deltas[i]))
        plt.xlabel("rho")
        plt.ylabel("deltas")
    plt.savefig(name)

#绘制社区原始图
def draw_community_original(graph, name="0_original.jpg"):
    plt.cla()
    nx.draw_circular(graph, with_labels=False, node_size=50, width=0.05)
    plt.savefig(name)

#绘制社区聚类之后的图
def draw_community(graph, halo, centers, name="0_community.jpg"):
    centers_len = len(centers)
    halo_len = len(halo)
    #com是个字典key存放其所属社区编号，每个list存放该社区的结点编号
    com = {}
    for i in range(centers_len):
        list_temp = []
        for j in range(halo_len):
            if (halo[j] == i):
                list_temp.append(j)
        com[i] = list_temp
    colors = ['#000000' for x in range(len(halo))]
    for key in com:
        #为每个社区随机一种结点颜色
        color = '#%06X' % randint(0, 0xFFFFFF)
        for node in com[key]:
            colors[node] = color
    pos = nx.spring_layout(graph, iterations=15, seed=1721)
    plt.figure(figsize=(15, 9))
    plt.axis('off')
    nx.draw_networkx(graph, pos=pos, node_size=50, with_labels=False, width=0.05, node_color=colors)
    plt.savefig(name)


# 初始化节点邻接关系
def init_graph(datas):
    # 获取数据源长度及边的数量
    data_len = len(datas)
    # 绘制空图
    graph = nx.Graph()
    # 往图中添加边
    for i in range(data_len):
        graph.add_edge(datas[i][0], datas[i][1])
    return graph


# 计算结点之间的jaccard距离vsd
def get_vsd(graph):
    nodes_number = len(graph.nodes)
    vsd = np.zeros((nodes_number,nodes_number)).astype(np.double)
    # 对于每一对结点来计算其vsd
    for i in range(nodes_number):
        # 获取i点的邻居
        ni = list(graph.adj[i])
        for j in range(nodes_number):
            # 获取j点的邻居
            nj = list(graph.adj[j])
            up = len(set(ni).intersection(set(nj)))
            down = len(set(ni).union(set(nj)))
            if down == 0:
                vsd[i][j] =1
            else:
                vsd[i][j] =1 - (up/(down))
    return vsd


# 计算网络中结点间的最短距离ShortestDis , 使用基于堆优化的dijkstra
class Point():
    # index：该点的标号，dis：该点到起点的最短距离
    def __init__(self, index, dis):
        self.index = index
        self.dis = dis

    def __lt__(self, other):
        if self.dis < other.dis:
            return True
        else:
            return False


def get_shortestDis(graph):
    nodes_number = len(graph.nodes)
    shortestDis = np.zeros((nodes_number, nodes_number)).astype(np.float64)
    # 基于堆优化的dijkstra
    graph_temp = {i: {} for i in range(nodes_number)}
    for i in graph.edges:
        graph_temp.get(i[0])[i[1]] = 1
        graph_temp.get(i[1])[i[0]] = 1
    for i in range(nodes_number):
        vis = [False] * (nodes_number)
        myheap = []
        dis = [float("inf")] * (nodes_number)
        dis[i] = 0
        heappush(myheap,Point(i,0))
        while len(myheap) > 0:
            x = heappop(myheap)
            index = x.index
            if vis[index]:
                continue
            vis[index] = True
            for des,w in graph_temp.get(index).items():
                if dis[des] > dis[index]+w:
                    dis[des] = dis[index]+w
                    heappush(myheap,Point(des,dis[des]))
        for j in range(nodes_number):
            shortestDis[i][j] = dis[j]
    return shortestDis


def getNodeOrderByDensity(G):
    # 计算结点之间的jaccard距离vsd
    vsd = get_vsd(G)
    # 计算网络中结点间的最短距离ShortestDis , 使用基于堆优化的dijkstra
    shortestDis = get_shortestDis(G)
    # vsd_sd能够很好的度量结点间的全局距离
    vsd_sd = vsd * shortestDis

    # 得到dc
    dc = select_dc(vsd_sd)
    # print("dc:", dc)
    # 计算局部密度
    rho = get_density(vsd_sd, dc)
    # 计算密度距离
    deltas, nearest_neiber = get_deltas(vsd_sd, rho)
    centers = find_centers_K(rho, deltas, len(G.nodes))
    return centers

if __name__ == '__main__':
    G = load_graph_noRealLable("dataset/real networks/dolphin.txt")
    print(getNodeOrderByDensity(G))