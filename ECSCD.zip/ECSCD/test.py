import random

import pandas as pd
import numpy as np
from math import exp, log
# cg_curve = np.zeros((1, 30))
cg_curve1 = np.zeros((1, 30))
import heapq
#
# a = cg_curve[0]
# b = cg_curve1[0]
# print(a)  #变成一维数组
# dataframe = pd.DataFrame(cg_curve1)
# dataframe.to_csv("result_all/test.csv",index=False,sep=",")

# array = np.array([1.123456789, 2.23456, 4.5643])
#
# # print(np.around(array, 3))
# print(np.around(0.59))
# print(np.around(-0.51))
# for t in range(1, 1001):
#     a = 1 - exp(-log(t+1))
#     a = 1/(2*a)
#     print(a)
#
# b =np.array([[0,1,2,3],[4,5,6,7]])
# print(np.max(b,axis=1))
# c=np.array([0,2,3,1])
# print(c-2)
# print(np.ceil(-5.5))
# a=np.zeros(5)
# print(a[3])
# a = np.array([7,1,3,2,5,6,4])
# print(np.max(a))
# print(np.argmax(a))
# max_indexs = heapq.nlargest(3,range(len(a)),a.take)
# print(max_indexs)
# a= np.array([[1,2],[3,4],[5,6],[]])
# b =  [7]
# a[3,:] =b
# print(a)
# b = np.array([7,8,9,10,11,12])
# b.
# print(a[2])
# print(1 if a[2]==[] else 0)

# print(len(a))
# b = a.argsort()
# print(b)
# print(b/2)
# a= np.logical_not(np.logical_xor(0,0))
# print(a)
# print(a*10)
# print(abs(-1))

# m = {}
# if not m:   #判断是否为空
#     print("empty")
# else:
#     print("full")
# print(np.random.randint(0, 2,10))
# print(np.random.randint(0, 1,10))
# c = [12,3]
# d = [4,5]
# e = []
# e.append(c)
# e.append(d)
# print(e)
# a = np.empty(shape=(5,6))
# print(a)
# a = np.array([[1,2,3],[4,5,6],[7,8,9]])
# print(a)
# g = np.array([[0,0,0]])
# a[1,:] = g[0]
# print(a)
import heapq

# fitness = np.array([1, 8, 2, 23, 7, -4, 18, 23, 42, 37, 2])
# max_indexs = heapq.nlargest(3, range(len(fitness)), fitness.take)
# print(max_indexs)
# min_indexs = heapq.nsmallest(3, range(len(fitness)), fitness.take)
# print(min_indexs)
#
# if -4 in fitness:
#     print(10)

# list = [2,2,3,4,4,5,5,5,5,6,7,8,8,8]
# print(max(list))
# print(list.index(max(list)))
# a = [[1,2,3],[4,5,6]]
# print(a[0][2])

#数据类型  python
# a = [0,2,1] #lsit
# b = {'a':1,} #dic
# c = 1
# d = 1.52
# e = "abc"
# f = True
# g = set([0,2,1,1,2])
# h = tuple

# a = 'abc'
# print(len(a))

# def ene(encode,key):
#     q = []
#     result = ""
#     for x in key:
#         q.append(int(x))  #[4,1,2]
#     head = 0
#     for eh in encode:
#         if eh >= 'a' and eh <='z':
#             x = q[head]   #x 为密钥
#             head+=1
#             q.append(x)
#             t = ord(eh)-ord("a")
#             eh =
#     return result
# from load_graph import load_graph_noRealLable
# G = load_graph_noRealLable("dataset/real networks/karate.txt")
# print(list(G.adj[2]))
# print(type(G.nodes))
# # print(int(G.nodes))
# print(len(list(G.nodes)))
# print(list(G.adj[2]))
# x = [[1,23,4],[1,2]]
# print(len(x))
# x = [1,2,3]
# print(sum(x))

# x = [0,0,0,0,1,2,2,0,3,3,1,4,4,0,3,3,2,5,3,0,3,0,3,3,3,3,3,3,3,3,3,3,3,3]
# x1 = []
# for i in range(len(x)):
#     x1.append(x[i]+1)
# print(x1)
# print(1.0/2.5)
# X1 = [5,1,2,2,2,2,3,3,3,4,4,4,4]
# x = [1,2]
# import collections
# m = collections.defaultdict(int)
# for i in X1:
#     if i in x:
#         m[i]+=1
# max_v = max(m.values())
# print([item[0] for item in m.items() if item[1] == max_v])
# print(m)
# t1  = np.array([-0.4,0.8,0.5,-0.2,0.3])
# print(t1)
# t1 = t1.tolist()# 去重升序
# print(t1)
# print(type(t1))


# t1  = np.array([-0.4,0.8,0.5,-0.2,0.3])
# t2  = np.array([-0.5,0.4,-0.2,0.7,-0.1])
# print(random.choice(t1))

# def cos_sim(a, b):
#     a_norm = np.linalg.norm(a)
#     b_norm = np.linalg.norm(b)
#     cos = np.dot(a,b)/(a_norm * b_norm)
#     return cos
# print(cos_sim(t1,t2))
# def cosine_similarity(x,y):
#     num = x.dot(y.T)
#     denom = np.linalg.norm(x) * np.linalg.norm(y)
#     return num / denom
# print(cosine_similarity(t1,t2))
# import matplotlib.pyplot as plt
# import numpy as np
#
# # 创建一个随机的矩阵
# data = np.random.rand(10, 10)
#
# # 绘制热力图
# plt.imshow(data, cmap='hot', interpolation='nearest')
#
# # 显示图像
# plt.show()
import networkx as nx
import random
import matplotlib.pyplot as plt
from sklearn.decomposition import TruncatedSVD
# 创建一个空的无向图
G = nx.Graph()

# 添加 10 个随机节点
for i in range(14):
    G.add_node(i)

# 添加 20 条随机边
for i in range(30):
    u = random.randint(0, 13)
    v = random.randint(0, 13)
    if u != v:
        G.add_edge(u, v)
# 获取邻接矩阵
adj_matrix = nx.adjacency_matrix(G).todense()
# 保存邻接矩阵到txt文件
with open('adj_matrix_1.txt', 'w') as f:
    np.savetxt(f, adj_matrix, fmt='%d')
# 输出图形信息
print("节点数:", G.number_of_nodes())
print("边数:", G.number_of_edges())
# 可以使用 Matplotlib 绘制图形
nx.draw(G, with_labels=True)
plt.savefig('random_graph_1.png')
# # 使用AROPE三阶降维邻接矩阵并将结果保存为文本文件
# svd = TruncatedSVD(n_components=3)
# adj_matrix_reduced = svd.fit_transform(np.asarray(adj_matrix))
# np.savetxt('adj_matrix_reduced.txt', adj_matrix_reduced)

# def cosine_similarity(x,y):
#     num = x.dot(y.T)
#     denom = np.linalg.norm(x) * np.linalg.norm(y)
#     return num / denom
#
# x14=np.array([1.782225747432064855e+00,1.515908457316554880e+00,-7.756571972820025529e-01])
# x9=np.array([1.095630005549802943e+00,-1.276461228087751199e+00,-7.778309721145945654e-02])
# x18=np.array([1.007004116507341340e+00,-6.484504553666150528e-01,-7.953514357473362439e-01])
# x3=np.array([5.280544170687938577e-01, 6.045888788373550149e-01, -3.327204242669598577e-01])
# x7=np.array([1.256007711578066122e+00, -5.667204874518511071e-01, -7.452703092681116637e-01])
# x10=np.array([9.343580857527301609e-01 ,-1.648442003837644332e-01, -8.097952308563826085e-01])
# x19=np.array([1.277647883897807590e+00, 1.101731149444554303e+00, 4.250445977645399553e-01])
# x_14= np.array([0,0,0,0,1,0,0,1,0,1,1,0,1,0,0,1,0,0,1,0])
# x_9= np.array([0,0,0,1,0,0,0,0,1,0,0,0,0,0,1,0,0,0,0,1])
# x_18= np.array([0,0,0,1,0,0,0,1,0,0,0,0,0,0,1,0,1,0,0,0])
# x_3 = np.array([0,0,0,0,0,0,0,0,0,1,0,0,0,0,0,0,0,0,1,0])
# x_7 = np.array([0,0,0,0,0,0,0,0,0,0,1,0,0,0,1,0,0,0,1,1])
# x_19 = np.array([0,0,0,0,0,0,1,1,0,1,0,0,0,1,0,1,0,0,0,0])
# print("7,19",cosine_similarity(x7,x19))
# print("7.18",cosine_similarity(x7,x18))
# print("7,19",cosine_similarity(x_7,x_19))
# print("7,18",cosine_similarity(x_7,x_18))
# print("14,9",cosine_similarity(x14,x9))
# print("3.9",cosine_similarity(x3,x9))
# print("14,9",cosine_similarity(x_14,x_9))
# print("3.9",cosine_similarity(x_3,x_9))
# print("14,9",cosine_similarity(x14,x9))
# print("14.18",cosine_similarity(x14,x18))
# print("14,9",cosine_similarity(x_14,x_9))
# print("14,18",cosine_similarity(x_14,x_18))
import pandas as pd
import seaborn as sns
import matplotlib.pyplot as plt

# # 读取矩阵数据
# matrix = np.loadtxt('adj_matrix_reduced.txt')
# # 计算余弦相似度
# cosine_sim = np.zeros((20,20))
# for i in range(len(matrix)):
#     for j in range(len(matrix)):
#         vec1 = np.array(matrix[i])
#         vec2 = np.array(matrix[j])
#         cos_sim = vec1.dot(vec2) / (np.linalg.norm(vec1) * np.linalg.norm(vec2))
#         cosine_sim[i][j] = cos_sim
# np.savetxt('adj_matrix_reduced_cos.txt', cosine_sim, delimiter=',')



# # 读取矩阵文本文件
# matrix = pd.read_csv('adj_matrix_reduced_cos.txt', delimiter=',', header=None)
#
# # 绘制热力图
# sns.heatmap(data=matrix,annot=False,cmap="RdBu_r")
# # 保存热力图为png文件
# plt.savefig('heatmap_reduced.png')