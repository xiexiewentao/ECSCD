def cal_q(comm, G):
    # 边的个数
    edges = G.edges()
    m = len(edges)

    # 每个节点的度
    du = G.degree()

    # 通过节点对（同一个社区内的节点对）计算
    ret = 0.0
    for c in comm:
        for x in c:
            for y in c:
                # 边都是前小后大的
                # 不能交换x，y，因为都是循环变量
                if x <= y:
                    if (x, y) in edges:
                        aij = 1.0
                    else:
                        aij = 0.0

                else:
                    if (y, x) in edges:
                        aij = 1.0
                    else:
                        aij = 0
                tmp = aij - du[x] * du[y] * 1.0 / (2 * m)
                ret = ret + tmp

    ret = ret * 1.0 / (2 * m)

    return ret