import numpy as np
import math



def NMI_TEST(A, B):
    # 样本点数
    total = len(A)
    A_ids = set(A)
    B_ids = set(B)
    # 互信息计算
    MI = 0
    eps = 1.4e-45
    for idA in A_ids:
        for idB in B_ids:
            idAOccur = np.where(A == idA)
            idBOccur = np.where(B == idB)
            idABOccur = np.intersect1d(idAOccur, idBOccur)
            px = 1.0 * len(idAOccur[0]) / total
            py = 1.0 * len(idBOccur[0]) / total
            pxy = 1.0 * len(idABOccur) / total
            if px * py != 0:
                MI = MI + pxy * math.log(pxy / (px * py) + eps, 2)
    # 标准化互信息
    Hx = 0
    for idA in A_ids:
        idAOccurCount = 1.0 * len(np.where(A == idA)[0])
        Hx = Hx - (idAOccurCount / total) * math.log(idAOccurCount / total + eps, 2)
    Hy = 0
    for idB in B_ids:
        idBOccurCount = 1.0 * len(np.where(B == idB)[0])
        Hy = Hy - (idBOccurCount / total) * math.log(idBOccurCount / total + eps, 2)
    MIhat = 2.0 * MI / (Hx + Hy)
    return MIhat
# A = np.array([1, 1, 3, 3, 4, 4, 1, 1, 1, 1, 3, 3, 2, 2, 2, 1, 1, 1, 1, 3, 2, 3, 1, 1, 4, 2, 2, 1, 2])
# B = np.array([1,2,1,1,1,1,1,2,2,2,2,3,1,1,3,3,3])
# print(NMI.NMI(A,B))


def cal_Q(comm, G):
    # 边的个数
    edges = G.edges()
    m = len(edges)

    # 每个节点的度
    du = G.degree()

    # 通过节点对（同一个社区内的节点对）计算
    ret = 0.0
    for c in comm:
        for x in c:
            for y in c:
                # 边都是前小后大的
                # 不能交换x，y，因为都是循环变量
                if x <= y:
                    if (x, y) in edges:
                        aij = 1.0
                    else:
                        aij = 0.0

                else:
                    if (y, x) in edges:
                        aij = 1.0
                    else:
                        aij = 0
                tmp = aij - du[x] * du[y] * 1.0 / (2 * m)
                ret = ret + tmp

    ret = ret * 1.0 / (2 * m)

    return ret


def ACC(X,B):
    k = 0
    for i in range(len(X)):
        if X[i] == B[i]:
            k+=1
    return k/len(X)