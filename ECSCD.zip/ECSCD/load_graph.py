import numpy as np
import networkx as nx
'''
数据集下标是从0开始的
'''
def load_graph_noRealLable(path1):
    graph = nx.Graph()
    a = []
    with open(path1) as text:
        for line in text:
            vertices = line.strip().split(" ")
            a.append([int(i) for i in vertices])
    a = np.array(a)
    m = np.max(a)
    n = np.min(a)
    if n == 0:
        graph.add_nodes_from([i for i in range(m + 1)])
    else:
        graph.add_nodes_from([i for i in range(1, m + 1)])

    with open(path1) as text1:
        for line1 in text1:
            vertices1 = line1.strip().split(" ")
            source1 = int(vertices1[0])
            target1 = int(vertices1[1])
            graph.add_edge(source1, target1)
    graph = nx.convert_node_labels_to_integers(graph, ordering='sorted')
    gbest = []
    return graph

if __name__ == '__main__':
    # G = m2g.load_graph("dataset/Mozilla Firefox_matrix/browser.txt")  # 矩阵的图
    #G = gh.load_graph("dataset/real networks/karate.txt")  #点线图师姐发的gfx.txt
    G = load_graph_noRealLable("dataset/real networks/karate.txt")
    print(G)