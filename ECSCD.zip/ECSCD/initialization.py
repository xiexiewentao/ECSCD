import collections
import random
import matrix_to_graph as m2g
import numpy as np
from RRM import RRM
from orderNode import getNodeOrderByDensity
from sortbydensity import get_max_weight_node
import pandas as pd
import time
from partition import partition
from objectiveFunction import TurboMQ, NewTurboMQ
from evaluateFunction import MoJoFM
from evaluateFunction import MoJoFM
import sys
import pickle
from load_graph import load_graph_noRealLable
import NMI
from metric import *
'''
编码方式：
    编码：     [1,1,1,1,2,2,2]
    数组下标：   0,1,2,3,4,5,6
    即表示点{0,1,2,3}在社区1，点{4,5,6}在社区2

基本的标签传播算法(LPA)思想：
让每个结点与它的大多数邻居在同一个社区中。
具体算法流程为：
初始化，每个结点携带一个唯一的标签；（将初始化改为了没有入度的结点带一个唯一的标签）
然后更新结点的标签，令其标签与它的大多数邻居的标签相同，若存在多个则随机选择。(将邻居改为了后继)
迭代直至每个结点的标签不再变化。

'''


def can_stop(G, searchAgent, dim, X):
    # 所有结点的标签都和它邻居中出现频率最大的标签一致时停止
    for i in range(searchAgent):
        for j in range(dim):
            label = X[i, j]
            if G.degree[j]  != 0:  # 节点j的出度      从有出度的节点开始
                max_labels = get_max_neighbor_label(G, X[i, :], j)
                if (label not in max_labels):
                    return False
    return True


def get_max_neighbor_label(G, X, node):  # X = X[i,:] 第i-1个 个体  node = j     返回节点j邻居节点出现的最大次数的标签（对应的簇数）
    m = collections.defaultdict(int)  # 以键值对(字典)的方式计数
    # neighbors = (list(G.adj(node)) + list(G.successors(node)))  # G.predecessors(node) 指向node的节点   [j前，j后]
    neighbors = list(G.adj[node])
    for neighbor_index in neighbors:
        neighbor_label = X[neighbor_index]
        m[neighbor_label] += 1  # neighbor_label（节点）出现一次就加1
    if not m:  # 孤立结点就返回一个[]
        return []
    else:
        max_v = max(m.values())  # 返回出现最多的节点的次数
        # m.items() = ([(neigbor_lable1,出现次数),(neigbor_lable2,出现次数)...])
        return [item[0] for item in m.items() if item[1] == max_v]  # 如果有多个max_v就返回list


def populate_label(G, searchAgent, dim, X):  # 访问随机长度的随机序列    孤立结点不改变label
    iso_list = set()
    # iso_list_1 = set()
    for i in range(int(searchAgent / 2)):
        a = int(dim * random.random())
        visitSequence = np.random.choice(G.nodes,
                                      a,replace=False)
        # sample(list, k)返回一个长度为k新列表，新列表存放list所产生k个随机唯一的元素(因为G.nodes是唯一的—）
        for j in visitSequence:
            label = X[i, j]
            if G.degree[j] != 0:
                max_labels = get_max_neighbor_label(G, X[i, :], j)  # 获取最大的邻居标签
                if (label not in max_labels):
                    newLabel = random.choice(max_labels)
                    X[i, j] = newLabel
            else:
                iso_list.add(j)
        # for j in visitSequence:
        #     label = X[i, j]
        #     if G.out_degree(j) != 0:
        #         max_labels = get_max_neighbor_label(G, X[i, :], j)  # 获取最大的邻居标签
        #         # 所有邻居的标签出现次数都一样，则随机选取其中一个标签
        #         if (label not in max_labels):
        #             newLabel = random.choice(max_labels)
        #             X[i, j] = newLabel
        #     else:
        #         if G.in_degree(j) != 0:
        #             max_labels = get_max_neighbor_label(G, X[i, :], j)  # 获取最大的邻居标签
        #             # 所有邻居的标签出现次数都一样，则随机选取其中一个标签
        #             if (label not in max_labels):
        #                 newLabel = random.choice(max_labels)
        #                 X[i, j] = newLabel

    for i in range(int(searchAgent / 2), searchAgent):
        visitSequence = getNodeOrderByDensity(G)
        for j in visitSequence:
            label = X[i, j]
            if G.degree[j] != 0:
                max_labels = get_max_neighbor_label(G, X[i, :], j)  # 获取最大的邻居标签
                if (label not in max_labels):
                    newLabel = random.choice(max_labels)
                    X[i, j] = newLabel
            else:
                iso_list.add(j)
    # for i in range(int((searchAgent * 2) / 3), searchAgent):
    #     visitSequence = get_max_weight_node(G)
    #     if G.degree[j] != 0:
    #         max_labels = get_max_neighbor_label(G, X[i, :], j)  # 获取最大的邻居标签
    #         if (label not in max_labels):
    #             newLabel = random.choice(max_labels)
    #             X[i, j] = newLabel
    #     else:
    #         iso_list.add(j)
    return X, list(iso_list)


def initialization(G, searchAgent, dim, LPA_max_iter):  # 输出的X为已经去冗余后的X
    # 初始化标签，每个结点携带一个唯一的标签
    X = float("inf") * np.ones((searchAgent, dim))  # searchAgent行，dim列的二维数组

    for i in range(searchAgent):
        for j in range(dim):
            X[i, j] = j
    # print("before x", X)
    # 更新标签
    iter_time = 0
    while (not can_stop(G, searchAgent, dim, X) and iter_time < LPA_max_iter):
        X, iso_list = populate_label(G, searchAgent, dim, X)
        # print("after x", X)
        iter_time += 1
    for i in range(searchAgent):
        X[i] = RRM(X[i])  # 去冗余后的
    # for i in range(searchAgent):
    #     max_clu = np.max(X[i])
    #     #min_clu = np.min(X[i],axis=1) 就是0
    #     X[i] = X[i]-np.floor(max_clu/2)
    # for i in range(0, searchAgent):
    #     for j in range(dim):
    #         if X[i, j] > (u-1):
    #             X[i, j] = (u-1)
    # if X[i,j]<(l+1):
    #     X[i,j] = (l+1)
    # print(type(X))  #<class 'numpy.ndarray'>
    # print("initial x", X)
    # print("x.shape", X.shape)  # (30,45)   #30个个体，45列
    # 按照奇偶数来交换，奇数的全在前15个，偶数的则全在后面
    # for i in range(1, searchAgent, 2):
    #     j = searchAgent - i - 1
    #     if i < j:
    #         X[[i, j], :] = X[[j, i], :]
    return X, iso_list


if __name__ == '__main__':
    G = load_graph_noRealLable("dataset/real networks/LFR/LFR_MU/EDGE_LIST/0.8.txt")
    dim = len(G.nodes)
    searchAgent = 30
    LPA_max_iter = 5
    # u = dim / 3  # 上界
    # l = 2  # 下界
    u = np.ceil(dim / 2)
    l = 0
    B = [1,2,3,4,5,6,6,4,7,8,9,10,9,6,8,8,6,9,11,8,12,3,1,7,13,12,14,4,12,15,7,12,7,9,9,6,11,8,1,1,12,13,16,1,2,16,6,1,1,3,6,3,12,16,10,5,5,1,5,8,8,2,8,16,8,8,12,11,9,15,2,5,10,5,6,3,12,9,17,10,3,3,2,14,3,3,2,17,10,17,1,15,11,15,3,9,10,7,11,2,9,8,3,3,3,4,14,17,14,17,17,14,17,6,14,10,10,13,15,17,10,9,8,14,4,9,4,10,15,12,7,7,17,17,17,9,17,2,4,7,7,17,6,14,17,8,4,11,11,15,4,10,7,12,3,8,4,12,17,1,11,1,3,17,17,7,6,13,3,7,1,13,4,3,12,13,6,16,10,5,5,10,5,12,6,3,13,1,16,11,12,9,16,3,12,5,13,15,16,5,15,16,9,5,11,14,15,17,15,15,2,17,9,9,2,11,14,9,15,2,17,14,2,2,2,9,5,14,13,9,3,14,8,12,8,4,2,10,13,7,14,15,4,9,2,13,8,14,8,13,4,8,6,16,6,8,10,11,10,2,6,8,4,14,17,8,15,17,2,17,10,17,13,8,6,8,1,17,17,15,3,6,17,6,3,12,3,7,2,17,3,4,17,2,11,9,5,5,16,3,6,8,17,3,14,6,17,8,3,8,11,16,17,13,8,5,8,17,1,17,9,11,11,16,15,4,15,9,2,15,3,15,8,10,15,15,14,10,8,14,10,9,9,8,13,15,2,1,9,15,5,2,7,7,3,9,8,16,7,9,10,7,15,4,4,7,15,12,13,3,14,13,4,17,14,8,4,13,8,14,6,2,14,14,10,2,16,15,13,5,2,6,2,3,16,17,14,4,15,8,17,10,6,9,9,1,13,16,1,8,8,7,17,8,17,3,17,3,11,12,3,7,4,8,15,3,11,4,17,12,1,17,10,17,17,10,17,16,14,13,4,3,3,10,16,1,8,17,5,10,2,4,8,2,5,5,2,8,16,17,14,9,1,3,4,2,1,17,3,17,8,11,14,10,15,2,2,9,7,10,3,1,14,17,11,13,3,8,8,8,3,14,15,5,7,13,6,6,10,3]
    # print(initialization(G, searchAgent, dim, LPA_max_iter))
    X, iso_list = initialization(G, searchAgent, dim, LPA_max_iter)   #(30, 34)
    for i in range(len(X)):
        print(i)
        X[i]= X[i].tolist()
        for j in range(len(X[i])):
            X[i][j] = int(X[i][j]+1)
        X[i] = RRM(X[i]).tolist()
        print(X[i])
        NMI_v = NMI.NMI_TEST(np.array(X[i]), np.array(B))
        #Q=cal_Q(partition(X[i]), G)
        # print("NMI:%s,Q:%s" % (NMI_v, Q))
        print("nmi:",NMI_v)
        # print("Q:%s"%(Q))
    # print(X.shape)
    # timerStart = time.time()
    # MQ = []
    # MOJO = []
    # for i in range(searchAgent):
    #     MQ.append(TurboMQ(partition(X[i]), G))
    #     MOJO.append(MoJoFM(X[i], B))
    # print("mean", np.mean(MQ))
    # print("median", np.median(MQ))  # 取中位数
    # print("best", max(MQ))
    # print("*" * 8)
    # print("mean", np.mean(MOJO))
    # print("median", np.median(MOJO))  # 取中位数
    # print("best", max(MOJO))
    # print(X[np.argmax(MQ), :])  # 打印种群MQ最大值那一行     np.argmax(MQ)取索引
    # print(X[np.argmax(MOJO), :])
    # print(MoJoFM(X[np.argmax(MQ), :], B))
