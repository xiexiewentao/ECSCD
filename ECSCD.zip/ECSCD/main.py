# This is a sample Python script.

# Press Shift+F10 to execute it or replace it with your code.
# Press Double Shift to search everywhere for classes, files, tool windows, actions, and settings.

import matrix_to_graph as m2g
import Graphhelper as gh
from RRM import RRM
from initialization import initialization
from CSA import Chameleon
import math
from objectiveFunction import TurboMQ
from evaluateFunction import MoJoFM, get_F_measure
import time
from partition import partition
import pandas as pd
import numpy as np
from metric import *
from load_graph import load_graph_noRealLable
import NMI
if __name__ == '__main__':
    G = m2g.load_graph("adj_matrix.txt")  # 矩阵的图
    #G = gh.load_graph("dataset/real networks/karate.txt")  #点线图师姐发的gfx.txt
    #G = load_graph_noRealLable("dataset/real networks/lesmis.txt")
    # broswer的专家分解
    # B = [1,2,1,1,1,2,2,2,1,2,1,1,1,2,1,1,1,2,1,2,1,1,2,1,1,2,2,2,1,1,1,2,2,1,1,1,1,1,1,1,1,2,1,1,1,1,1,1,2,1,1,1,1,1,2,1,2,2,1,1,2,1]
    # B = [1, 2, 2, 2, 1, 2, 1, 1, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 1, 2, 2, 2, 2, 2, 2, 2, 2, 2, 1, 2, 2, 2, 2, 2, 2, 2, 2,
    #      2, 2, 2, 2, 2, 2, 2, 2, 2, 1, 2, 1, 2, 2, 1, 2, 2, 2, 2, 2, 2, 2, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 1, 3, 3, 3, 3,
    #      3, 3, 1, 2, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 1, 1]

    dim = len(G.nodes)  # 维度为图的结点数     [1,3,2,4,2,3],上下限为取值范围，维度则为结点数（数组长度）
    searchAgent = 30
    max_iteration = 100
    # u = math.ceil(dim / 3)  # 上界  最大是有第dim/3个簇  2-n/3
    # l = 2  # 下界   最小是有两个簇
    # u1=np.ceil(dim/6)
    # l1 = np.floor(-(dim/6))
    LPA_max_iter = 5
    start_time = time.time()
    # 初始化种群
    chameleonPositions, iso_list = initialization(G, searchAgent, dim, LPA_max_iter)
    # 传入的去过冗余化但未经过分区的个体
    bestFitness, bestPostion, CSAConvcurve, csa_gbest = Chameleon(searchAgent, max_iteration, dim,
                                                                  chameleonPositions, G, iso_list)
    end_time = time.time()
    bestPostion = RRM(bestPostion).tolist()
    for i in range(len(bestPostion)):
        bestPostion[i] = int(bestPostion[i] + 1)

    print("bestPostion is ", bestPostion)
    # 保存每次迭代的适应度
    dataframe_1 = pd.DataFrame(CSAConvcurve)
    dataframe_1.to_csv("result_all/browser_MQ_KKM.csv", index=False, sep=",")
    dataframe_2 = pd.DataFrame(csa_gbest)
    dataframe_2.to_csv("result_all/browsergbest.csv", index=False, sep=",")

    Q = cal_Q(partition(bestPostion), G)
    print("q=",Q)
    # for i in bestPostion:
    #     best_int.append(int(i))


    #NMI = NMI.NMI_TEST(np.array(bestPostion), np.array(B))
    #precision, recall, fm = get_F_measure(bestPostion, B)
    #ACC = ACC(bestPostion, B)
    #print("Q = %s,NMI = %s,precison = %s,recall = %s,ACC = %s" % (Q, NMI, precision, recall, ACC))


    print(end_time-start_time)
    # 评估得到的最佳位置
    # MQ_1 = TurboMQ(partition(bestPostion_MQ), G)
    # MQ_2 = TurboMQ(partition(bestPostion_GS), G)
    # mojo_1 = MoJoFM(bestPostion_MQ, B)
    # mojo_2 = MoJoFM(bestPostion_GS, B)
    # precision_1, recall_1, fm_1 = get_F_measure(bestPostion_MQ, B)
    # precision_2, recall_2, fm_2 = get_F_measure(bestPostion_GS, B)
    # total_time = str(end_time - start_time)
    # print("The Best  MQ_1 value", MQ_1)
    # print("The Best  MQ_2 value", MQ_2)
    # print("The Best  MoJoFM_1 value", mojo_1)
    # print("The Best  MoJoFM_2 value", mojo_2)
    # print("The Best  precision_1 value", precision_1)
    # print("The Best  precision_2 value", precision_2)
    # print("The Best  recall_1 value", recall_1)
    # print("The Best  recall_2 value", recall_2)
    # print("The Best  fm_1 value", fm_1)
    # print("The Best  fm_2 value", fm_2)
    # print("The time consume", total_time)
