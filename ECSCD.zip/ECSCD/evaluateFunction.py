import numpy as np
from collections import Counter
import copy
from partition import partition

#简易版 基于BFS的匈牙利算法求解二部图的最大匹配数
#时间复杂度为O(V⋅E)
def BFS_hungary(g, Nx, Ny, Mx, My, chk, Q, prev):

    res = 0
    for i in range(Nx):
        if Mx[i] == -1:
            qs = qe = 0
            Q[qe] = i
            qe += 1
            prev[i] = -1

            flag = 0
            while (qs < qe and not flag):
                u = Q[qs]
                for v in range(Ny):
                    if flag: continue
                    if g[u][v] and chk[v] != i:
                        chk[v] = i
                        Q[qe] = My[v]
                        qe += 1
                        if My[v] >= 0:
                            prev[My[v]] = u
                        else:
                            flag = 1
                            d, e = u, v
                            while d != -1:
                                t = Mx[d]
                                Mx[d] = e
                                My[e] = d
                                d = prev[d]
                                e = t
                qs += 1
            if Mx[i] != -1:
                res += 1

    return res,Mx

def calculateCost(A,B,ClusterNumofA,ClusterNumofB):

    #获取B在A中的tag
    tag = []
    visit = [0] * len(A)
    for i in range(len(A)):
        if visit[i] == 0:
            temp = A[i]
            temptag = []
            for j in range(i, len(A)):
                if A[j] == temp:
                    temptag.append(B[j])
                    visit[j] = 1  #已经遍历过的变成1
            tag.append(temptag)    #tag每一个元素都为A中同一个元素所在的B对应的元素   ，是一个二维数组

    #二部图初始化
    BipartGraph = [[0 for i in range(ClusterNumofB)] for j in range(ClusterNumofA)]   #二维数组

    #获取每个集合G中的最频繁标签并创建二部图
    for i in range(ClusterNumofA): #ClusterNumofA  A有几类
        maxtag = []
        frequency = Counter(tag[i]).most_common(1)[0][1]    #Counter:计数并返回一个字典，键为元素，值为元素个数
        # most_common(n)返回一个列表，包含counter中前n个最大数目的元素   [0][1]出现最多的元素的次数
        num = len(set(tag[i]))
        for j in range(num):
            if (Counter(tag[i]).most_common(j+1)[j][1]) == frequency :    #前j+1个中第j个的key，即元素出现的次数
                maxtag.append(Counter(tag[i]).most_common(j+1)[j][0])  #前j+1个中第j个的key，即元素的值
            else: continue
        for j in maxtag:
            BipartGraph[i][j] = 1

    #获取二部图的最大匹配数及匹配路径
    xMark = [-1 for i in range(ClusterNumofA)]
    yMark = [-1 for i in range(ClusterNumofB)]
    chk = [-1 for i in range(ClusterNumofB)]
    Q = [0 for i in range(1000)]
    prev = [0 for i in range(1000)]
    g, path = BFS_hungary(BipartGraph, ClusterNumofA, ClusterNumofB, xMark, yMark, chk, Q, prev)

    #创建集合Gk
    G = [[] for i in range(ClusterNumofB)]
    EmptyGroup = []
    for i in range(len(path)):
        if path[i] != -1 :
            G[path[i]] = copy.deepcopy(tag[i])
        else :
            EmptyGroup.append(i)
    for i in EmptyGroup:
        G[Counter(tag[i]).most_common(1)[0][0]] = G[Counter(tag[i]).most_common(1)[0][0]] + tag[i]

    #Move操作
    moves = 0
    for i in range(ClusterNumofB):
        for j in range(ClusterNumofB):
            if i != j :
                for k in G[j]:
                    if k == i :
                        moves += 1

    totalCost = moves + ClusterNumofA - g

    return totalCost

def maxDistanceTo(B,ClusterNumofB):

    num = []
    # 获取A的分类
    clusterB = []
    visit = [0] * len(B)
    for i in range(len(B)):
        if visit[i] == 0:
            temp = B[i]
            nodelist = []
            for j in range(i, len(B)):
                if B[j] == temp:
                    nodelist.append(j)
                    visit[j] = 1
            clusterB.append(nodelist)

    for i in range(ClusterNumofB):
        num.append(len(clusterB[i]))
    sort_order = np.argsort(num)  #返回从小到大的索引值

    G = 0
    for i in sort_order:
        if num[i] > G :
            G += 1

    maxDis = len(B) - G
    return maxDis

def MoJoFM(A,B):
    ClusterNumofA = len(set(A))  # 有序无重复,A有几类
    ClusterNumofB = len(set(B))  # 有序无重复，B有几类

    totalCost = calculateCost(A, B, ClusterNumofA, ClusterNumofB)
    maxDis = maxDistanceTo(B, ClusterNumofB)

    mojofm = 1 - totalCost / maxDis

    return mojofm

def get_TP(A,B):

    clusB = partition(B)
    TP = 0
    for clus in clusB:
        for i in range(len(clus)):
            for j in range(i+1,len(clus)):
                if A[clus[i]] == A[clus[j]]:
                    TP += 1

    return TP

def get_FN(A,B):

    clusB = partition(B)
    FP = 0
    for clus in clusB:
        for i in range(len(clus)):
            for j in range(i + 1, len(clus)):
                if A[clus[i]] != A[clus[j]]:
                    FP += 1

    return FP

def get_FP(A,B):

    clusA = partition(A)
    clusB = partition(B)
    FN = 0
    for clus in clusA:
        for i in range(len(clus)):
            for j in range(i + 1, len(clus)):
                if B[clus[i]] != B[clus[j]]:
                    FN += 1

    return FN

def get_F_measure(A,B):
    TP = get_TP(A, B)
    FN = get_FN(A, B)
    FP = get_FP(A, B)

    if TP + FP == 0:
        precision = 0
    else:
        precision = TP / (TP + FP)

    if TP + FN == 0:
        recall = 0
    else:
        recall = TP / (TP + FN)

    if precision + recall == 0:
        fm = 0
    else:
        fm = (2 * precision * recall) / (precision + recall)

        return precision, recall, fm


if __name__ == '__main__':
    A = [1, 1, 1, 1, 0, 0, 1, 1, 1, 0, 0, 0, 0, 0, 2, 0, 3, 3, 3, 7, 1, 1, 6, 6, 6, 6, 7, 6, 6, 7, 7, 6, 6, 7, 7, 7, 7,
         7, 7, 7, 7, 7, 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 2, 1, 1,
         1, 0, 0, 0, 0, 0, 0, 3, 3, 3, 3, 3, 3, 3, 3, 0, 4, 0, 9, 11, 12, 12, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
         0, 0, 12, 0, 0, 0, 8, 0, 0, 12, 12, 10, 10, 0, 3, 7, 0, 0,
         6, 6, 0, 5, 5, 5, 5, 5, 8, 8, 0, 8, 8, 9, 8, 8, 8, 9, 0, 0, 0, 0, 7, 8, 9, 12, 0, 0, 12, 12, 0, 0, 5, 5, 5, 5,
         3, 3, 2, 2, 2, 2, 2, 0, 0, 0, 0, 0, 2, 3, 0, 0, 2, 0, 0, 0, 0,
         2, 8, 8, 11, 10, 10, 12, 10, 10, 10, 10, 0, 0, 3, 3, 4, 0, 3, 7, 3, 9, 9, 9, 0, 3, 3, 3, 0, 6, 0, 0, 2, 2, 0,
         0, 2, 0, 2, 0, 0, 0, 3, 0, 3, 3, 3, 3, 0, 0, 0, 3, 0, 3, 3, 0,
         0, 0, 0, 0, 0, 0, 9, 12, 12, 12, 12, 12, 12, 12, 12, 0, 2, 3, 11, 2, 0, 0, 0, 2, 2, 2, 2, 0, 2, 2, 2, 2, 0, 2,
         2, 2, 2, 2, 2, 2, 0, 2, 2, 7, 7, 2, 2, 2, 2, 0, 2, 2, 0, 0, 3,
         3, 3, 3, 0, 0, 5, 0, 0, 0, 2, 0, 0, 6, 6, 6, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 0,
         0, 0, 0, 0, 0, 3, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 9, 0, 10,
         12, 12, 12, 12, 12, 12, 10, 10, 2, 0, 0, 5, 0, 2, 2, 2, 2, 0, 0, 0, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 7, 2, 2,
         2, 2, 2, 2, 0, 0, 2, 2, 2, 0, 0, 2, 7, 7, 7, 7, 0, 2, 2, 2, 0, 2,
         2, 0, 0, 0, 3, 3, 0, 3, 0, 12, 0, 6, 0, 0, 2, 3, 3, 0, 2, 3, 3, 3, 3, 3, 2, 3, 0, 0, 3, 3, 12, 12, 2, 0, 1, 9,
         6, 9, 7, 7, 0, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3,
         3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 7, 0, 0, 3, 6, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7,
         7, 0, 2, 2, 9, 12, 12, 10, 3, 3, 0, 0, 0, 3, 3, 3, 3, 5, 5, 3, 5, 5, 3,
         0, 3, 10, 10, 0, 12, 6, 6, 6, 6, 12, 8, 8, 8, 8, 0, 12, 12, 12, 12, 10, 0, 3, 0, 0, 8, 9, 10, 12, 10, 0, 10,
         10, 0, 0, 11, 10, 2, 0, 6, 6, 7, 7, 6, 7, 7, 7, 7, 6, 6, 6, 7, 7, 7,
         7, 7, 7, 7, 7, 7, 7, 12, 8, 12, 10, 12, 0, 7, 12, 12, 12, 0, 0, 4, 0, 5, 0, 0, 5, 5, 5, 5, 5, 2, 12, 12, 12,
         12, 12, 12, 12, 12, 12, 12, 12, 12, 12, 6, 7, 12, 6, 6, 6, 6, 6, 6, 6, 6,
         7, 7, 6, 6, 6, 7, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 7, 6, 6, 6, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7,
         7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7,
         7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 0, 0, 0, 0, 12, 12, 12, 12, 0, 12, 3, 3, 3, 8, 8, 8, 8, 8, 8, 12, 12, 12, 12,
         9, 11, 0, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 11,
         11, 12, 12, 12, 12, 12, 12, 12, 12, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10,
         10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10,
         10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10,
         10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10,
         10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10,
         10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10,
         10, 10, 10, 10, 10, 10, 10]
    B = [1, 1, 1, 1, 0, 0, 1, 1, 1, 0, 0, 0, 0, 0, 2, 0, 3, 3, 3, 7, 1, 1, 6, 6, 6, 6, 7, 6, 6, 7, 7, 6, 6, 7, 7, 7, 7,
         7, 7, 7, 7, 7, 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 2, 1, 1, 1, 0, 0, 0, 0, 0, 0
        , 3, 3, 3, 3, 3, 3, 3, 3, 0, 4, 0, 9, 11, 12, 12, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 12, 0, 0, 0,
         8, 0, 0, 12, 12, 10, 10, 0, 3, 7, 0, 0, 6, 6, 0, 5, 5, 5, 5, 5, 8, 8, 0, 8, 8,
         9, 8, 8, 8, 9, 0, 0, 0, 0, 7, 8, 9, 12, 0, 0, 12, 12, 0, 0, 5, 5, 5, 5, 3, 3, 2, 2, 2, 2, 2, 0, 0, 0, 0, 0, 2,
         3, 0, 0, 2, 0, 0, 0, 0, 2, 8, 8, 11, 10, 10, 12, 10, 10, 10, 10, 0, 0, 3, 3,
         4, 0, 3, 7, 3, 9, 9, 9, 0, 3, 3, 3, 0, 6, 0, 0, 2, 2, 0, 0, 2, 0, 2, 0, 0, 0, 3, 0, 3, 3, 3, 3, 0, 0, 0, 3, 0,
         3, 3, 0, 0, 0, 0, 0, 0, 0, 9, 12, 12, 12, 12, 12, 12, 12, 12, 0, 2, 3, 11, 2,
         0, 0, 0, 2, 2, 2, 2, 0, 2, 2, 2, 2, 0, 2, 2, 2, 2, 2, 2, 2, 0, 2, 2, 7, 7, 2, 2, 2, 2, 0, 2, 2, 0, 0, 3, 3, 3,
         3, 0, 0, 5, 0, 0, 0, 2, 0, 0, 6, 6, 6, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7,
         7, 7, 7, 7, 7, 7, 0, 0, 0, 0, 0, 0, 3, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 9, 0, 10, 12, 12, 12, 12, 12, 12,
         10, 10, 2, 0, 0, 5, 0, 2, 2, 2, 2, 0, 0, 0, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 7,
         2, 2, 2, 2, 2, 2, 0, 0, 2, 2, 2, 0, 0, 2, 7, 7, 7, 7, 0, 2, 2, 2, 0, 2, 2, 0, 0, 0, 3, 3, 0, 3, 0, 12, 0, 6, 0,
         0, 2, 3, 3, 0, 2, 3, 3, 3, 3, 3, 2, 3, 0, 0, 3, 3, 12, 12, 2, 0, 1, 9, 6, 9, 7,
         7, 0, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 7, 0, 0, 3, 6,
         7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 0, 2, 2, 9, 12, 12,
         10, 3, 3, 0, 0, 0, 3, 3, 3, 3, 5, 5, 3, 5, 5, 3, 0, 3, 10, 10, 0, 12, 6, 6, 6, 6, 12, 8, 8, 8, 8, 0, 12, 12,
         12, 12, 10, 0, 3, 0, 0, 8, 9, 10, 12, 10, 0, 10, 10, 0, 0, 11, 10, 2, 0, 6, 6,
         7, 7, 6, 7, 7, 7, 7, 6, 6, 6, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 12, 8, 12, 10, 12, 0, 7, 12, 12, 12, 0, 0, 4, 0, 5,
         0, 0, 5, 5, 5, 5, 5, 2, 12, 12, 12, 12, 12, 12, 12, 12, 12, 12, 12,
         12, 12, 6, 7, 12, 6, 6, 6, 6, 6, 6, 6, 6, 7, 7, 6, 6, 6, 7, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 7, 6, 6, 6, 7, 7, 7,
         7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7,
         7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 0, 0, 0, 0, 12, 12, 12, 12, 0,
         12, 3, 3, 3, 8, 8, 8, 8, 8, 8, 12, 12, 12, 12, 9, 11, 0, 10, 10, 10, 10,
         10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 11, 11, 12, 12, 12, 12, 12, 12, 12, 12, 10, 10, 10, 10, 10, 10, 10, 10,
         10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10,
         10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10,
         10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10,
         10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10,
         10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10,
         10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10]
    c = [0,0,1,1,2,1,1,1,1,1,1,1,1,1,1,0,1,0,0,2,1,1,1,1,2,1,1,1,1]
    d = [0,0,1,0,1,1,0,0,0,1,0,0,2,2,2,0,0,0,0,1,2,0,0,0,1,2,2,0,2]
    mojofm = MoJoFM(c, d)
    print(mojofm)