import numpy as np
# 划分社区：把基于字符串的标签转化为社区的分区
# 例如：[0,0,0,1,1,2,2]=>[[0,1,2],[3,4],[5,6]]
def partition(ind):#每一行
    community=[]
    cluster_num = []
    labels=np.unique(ind)
    labels_size=len(labels)
    for i in range(0,labels_size):
        community.append([j for (j,v) in enumerate(ind) if v==labels[i]])

    #for c in community:
        #cluster_num.append(len(c))

    return community

if __name__ == '__main__':
    X = np.array([0,0,3,3,2,0,0,3,1,1,1,2,2,1])
    print(partition(X))