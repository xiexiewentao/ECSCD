import Q_metric
from partition import partition
from load_graph import load_graph_noRealLable
from evaluateFunction import get_F_measure
from metric import *
import matrix_to_graph as m2g
from Q_metric import *
def get_Intra_edge_num(cluster, G):  # 因为是无向图，所以结果/2
    intra_edge_num = 0
    for i in cluster:
        for j in cluster:
            if (G.has_edge(int(i), int(j))) | (G.has_edge(int(j), int(i))):
                intra_edge_num += 1

    return intra_edge_num / 2


def get_Inter_edge_num(cluster, G):
    inter_edge_num = 0
    for i in cluster:
        for j in G.nodes:
            if j not in cluster:
                if (G.has_edge(i, j)) | G.has_edge(j, i):
                    inter_edge_num += 1

    return inter_edge_num / 2


def MFcalculation(cluster, G):
    i = get_Intra_edge_num(cluster, G)
    j = get_Inter_edge_num(cluster, G)
    if i == 0:
        MF = 0
    else:
        MF = i / (i + j / 2)
    return MF


def cd_Q(X, G):
    cluster_num = len(X)
    MF = []
    for i in range(cluster_num):
        clus = X[i]
        MF_value = MFcalculation(clus, G)
        MF.append(MF_value)
    MQ = sum(MF)
    return MQ


def cal_KM(clus, G):
    size = len(clus)
    inner_connect = 0
    for i in clus:
        for j in clus:
            if (G.has_edge(i, j)) | G.has_edge(j, i):
                inner_connect += 1
    return inner_connect / 2 / size


def cd_KKM(X, G):  # max    传过来的是分区好的簇
    nodes = list(G.nodes)
    node_num = len(nodes)  # 公式中的n
    KM = []
    cluster_num = len(X)  # 公式中的k
    for i in range(cluster_num):
        clus = X[i]
        KM.append(cal_KM(clus, G))
    KM_value = sum(KM)

    return (node_num - cluster_num) * 2 - KM_value


def finall_objective(X, G):
    return  0.05*cd_Q(X, G) - 0.95*cd_KKM(X, G)


if __name__ == '__main__':
    G = m2g.load_graph("test.txt")  #矩阵
    x_4_1 = [[0, 1, 5, 6], [9, 10, 13], [2, 3, 7, 8], [4, 11, 12]] #4种
    x_4_2 = [[0, 1, 5, 6], [8, 9, 13], [2, 3, 7], [4, 10, 11, 12]]
    x_4_3 = [[0, 1, 5, 6], [8, 9, 10, 13], [4, 11, 12], [2, 3, 7]]
    MQ_1 = cd_Q(x_4_1, G)
    Q_1= Q_metric.cal_q(x_4_1,G)
    KKM_1=cd_KKM(x_4_1,G)
    print("MQ_1:",MQ_1)
    print("Q_1:",Q_1)
    print("KKM_1:", KKM_1)
    MQ_2 = cd_Q(x_4_2, G)
    Q_2 = Q_metric.cal_q(x_4_2, G)
    KKM_2 = cd_KKM(x_4_2, G)
    print("MQ_2:", MQ_2)
    print("Q_2:", Q_2)
    print("KKM_2:", KKM_2)
    MQ_3 = cd_Q(x_4_3, G)
    Q_3 = Q_metric.cal_q(x_4_3, G)
    KKM_3 = cd_KKM(x_4_3, G)
    print("MQ_3:", MQ_3)
    print("Q_3:", Q_3)
    print("KKM_3:", KKM_3)


