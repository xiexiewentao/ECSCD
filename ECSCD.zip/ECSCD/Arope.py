import networkx as nx
import numpy as np
import matplotlib.pyplot as plt
from sklearn.decomposition import TruncatedSVD

# 随机生成20个节点，40条边的无向图
G = nx.gnm_random_graph(20, 40)

# 绘制图像并保存为png文件
nx.draw(G, with_labels=True)
plt.savefig('graph.png')

# 获取邻接矩阵
adj_matrix = nx.adjacency_matrix(G).todense()
# 保存邻接矩阵到txt文件
with open('adj_matrix.txt', 'w') as f:
    np.savetxt(f, adj_matrix, fmt='%d')

# 使用AROPE三阶降维邻接矩阵并将结果保存为文本文件
svd = TruncatedSVD(n_components=3)
adj_matrix_reduced = svd.fit_transform(adj_matrix)
np.savetxt('adj_matrix_reduced.txt', adj_matrix_reduced)
