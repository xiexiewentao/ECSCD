import random

import numpy as np
from objectiveFunction import objFunFirst1, objFunFirst2
from partition import partition
from math import exp, log, sqrt
from operAtor import *
from objectiveFunction import TurboMQ
from evaluateFunction import MoJoFM, get_F_measure
import heapq
from evo_objection import *
from RRM import RRM
from utils import *
from scipy.sparse import *

def AROPE_embedding(G):    #AROPE降维
    node_number = len(G.nodes)
    edgelist = np.array(G.edges)
    N = np.max(np.max(edgelist)) + 1
    A = csr_matrix((np.ones(edgelist.shape[0]), (edgelist[:, 0], edgelist[:, 1])), shape=(N, N))
    A += A.T
    order = [1, 2, 3, -1]  # 1,2,3,-1
    weights = []
    weights.append([1])
    weights.append([1, 0.1])
    weights.append([1, 0.1, 0.01])
    weights.append([0.001])  # 0.001
    U_list, V_list = AROPE(A, int(0.1*node_number), order, weights)
    # a=U_list[0][2]
    return U_list    #n*d维降维矩阵

def Chameleon(searchAgents, max_iteration, dim, chameleonPositions, G, iso_list):
    cg_curve = np.zeros(max_iteration)  # 记录每次迭代后的适应度
    csa_gbest = np.zeros((max_iteration, dim))  # 记录每次迭代后的全局最佳位置
    # MQ_KKM_gbest = np.zeros(max_iteration)
    '''
      # 评估初始种群的适应度
    # fit = np.zeros((searchAgents, 1));  # fit = [[0],[0],...,[0]]  30*1 二维
    # 第一次评估
    # for i in range(0, searchAgents):
    #     fit[i, 0] = objFunFirst(partition(chameleonPositions[i, :]), G)
    '''
    fit = np.zeros(searchAgents)
    for i in range(0, searchAgents):
        fit[i] = finall_objective(partition(chameleonPositions[i, :]), G)
    # 初始化CSA的参数
    fitness = fit  # 保存当前适应度结果
    fmax0 = np.max(fit)  # 获取最大值,每列的最大值
    index = np.argmax(fit)  # 获取最大值的索引
    chameleonBestPosition = chameleonPositions  # 当前的局部最佳个体即是初始化后的个体
    gPosition = chameleonPositions[index, :]  # 取全局最佳的个体     np.dnarray
    # print(type(gPosition))
    # gPosition_1 = gPosition.tolist()
    # # print(type(gPosition_1))
    # print(gPosition_1)
    # gPosition_2 = []
    # for i in range(len(gPosition_1)):
    #     gPosition_2.append(int(gPosition_1[i]+1))
    # print(gPosition_2) #[1, 1, 1, 1, 1, 2, 2, 1, 3, 4, 1, 1, 1, 1, 4, 4, 2, 1, 4, 1, 4, 1, 4, 4, 5, 5, 4, 5, 4, 4, 3, 4, 4, 4]
    # print(type(gPosition_2[2]))
    velocity = np.random.randint(0, 2, size=(searchAgents, dim))  # 初始化速度 左闭右开
    v0 = 0.0 * velocity
    Apore_embadding = AROPE_embedding(G)
    print("init_best", gPosition)

    rho = 1.0
    gamma = 1.0  # 用于控制探索和开发能力   对于μ 公式6中的μ,求第一次位置的
    alpha = 4.0
    beta = 3.0

    select_change = 0.5

    # Start CSA
    for t in range(1, max_iteration + 1):
        print("start the %s iteration" % t)
        a = 1 - exp(-log(t + 1))  # 确保范围为 (0.5,1],很多都接近1
        omega = (1 - (t / max_iteration)) ** (rho * sqrt(t / max_iteration))  # ω惯性权重，随迭代次数线性减少  关于速度的参数 公式18  （0，1]
        p1 = exp(-2 * (t / max_iteration) ** 2)  # 由于p1和p2的取值范围有大有小，CSA可以在本地搜索和全局搜索之间交替进行   (e^-2,1]   单调递减
        p2 = 1 / (1 + exp((-t + max_iteration / 2) / 100))  # 单调递增    （0.00692，0.99312）
        mu = gamma * exp(-(alpha * t / max_iteration) ** beta)  # μ  更新位置的  (0,1) 单调递减

        # Update the position of CSA
        for i in range(0, searchAgents):
            if np.random.random_sample() > 0 :
                print("分段函数的上半部分开始运行")
                chameleonPositions[i, :] = RRM(changePos_1(RRM(chameleonPositions[i, :]),
                                                       andPlus_1(RRM(chameleonPositions[i, :]),
                                                                RRM(chameleonBestPosition[i, :]),
                                                                RRM(gPosition), p1, p2), G, iso_list))  # 有回滚操作，按边界节点变,不是边界节点不变
                # (chameleonPositions[i, :], andoR(
                # andPlus(andPosLess(chameleonBestPosition[i, :], gPosition), p1 * np.random.random_sample()),
                # andPlus(andPosLess(gPosition, chameleonPositions[i, :]), p2 * np.random.random_sample())), G)
            else:  # y = y +μ((u-l)r3+lb)sgn(rand - 0.5)  随机变换
                # 获取fitness前三个的下标
                print("分段函数的下半部分开始运行")
                max_indexs = heapq.nlargest(3, range(len(fitness)), fitness.take)  # 结果是一维数组  降序      取了下标
                min_indexs = heapq.nsmallest(1, range(len(fitness)), fitness.take)
                fit_first = RRM(chameleonPositions[max_indexs[0], :])
                fit_sec = RRM(chameleonPositions[max_indexs[1], :])
                fit_thi = RRM(chameleonPositions[max_indexs[2], :])
                chameleonPositions[i, :] = RRM(randChange(RRM(chameleonPositions[i, :]),fit_first, fit_sec, fit_thi,
                                                     iso_list,G))  #增加多样性，不回滚，且是不同邻居标签+1额外的数

        # Chameleon velocity updates and find a food source   这里p1,p2应该为一个常数
        for i in range(0,searchAgents):
            velocity[i, :] = update_velo(velocity[i, :], RRM(chameleonBestPosition[i, :]), RRM(chameleonPositions[i, :]), RRM(gPosition),1.494,
                                         1.494, omega)
            #     andOr(andPlus(velocity[i, :], omega),
            #     andPlus(andPosLess(chameleonBestPosition[i, :], chameleonPositions[i, :]),
            #             p1 * np.random.random_sample()),
            #     andPlus(andPosLess(gPosition, chameleonPositions[i, :]), p2 * np.random.random_sample()))
            for j in iso_list:
                velocity[i, j] = 0
            # chameleonPositions[i, :] = changePos(chameleonPositions[i, :],changPosByVel(v0[i,:],velocity[i,:],a),G)
            chameleonPositions[i, :] = RRM(changePos(RRM(chameleonPositions[i, :]), andVelLess(velocity[i, :], v0[i, :]),
                                                 G, Apore_embadding))  # 1变，变为所有邻居并比较适应度值，变大就变为它，没有最大的就不变
        v0 = velocity

        # handling boundary violations   更新适应度值
        for i in range(0, searchAgents):
            fit[i] = finall_objective(partition(chameleonPositions[i, :]), G)
            if fit[i] > fitness[i]:
                chameleonBestPosition[i, :] = chameleonPositions[i, :]
                fitness[i] = fit[i]

        # Evaluate the new positions    根据适应度值更新全局最佳位置
        fmax = np.max(fitness)
        index = np.argmax(fitness)
        if fmax > fmax0:
            gPosition = chameleonBestPosition[index, :]
            fmax0 = fmax
        print(gPosition)
        cg_curve[t - 1] = fmax0   #每次迭代后的适应度
        csa_gbest[t - 1, :] = gPosition  #记录每次迭代后的全局最佳位置
        # MQ_KKM_gbest[t-1,:] = finall_objective(partition(gPosition),G)
        print("end the %s iteration" % t)
    # ngPosition = np.nonzero(fitness == np.max(fitness))  # 返回位置  返回数组中非零元素的索引值数组
    # g_best = chameleonBestPosition[ngPosition[0], :]
    fmax0 = finall_objective(partition(gPosition), G)
    # gPosition = gPosition.tolist()
    # print(gPosition)




    return fmax0, gPosition, cg_curve, csa_gbest
