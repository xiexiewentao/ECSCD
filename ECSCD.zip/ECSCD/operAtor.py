import collections
import random

import numpy as np
from initialization import get_max_neighbor_label
from math import exp, log
from EdgeNodeMutation import edgeNodeMutation
from evo_objection import finall_objective
from partition import partition

import numpy as np

# def cosine_similarity(x, y, norm=False):
#     """ 计算两个向量x和y的余弦相似度 """
#     assert len(x) == len(y), "len(x) != len(y)"
#     zero_list = [0] * len(x)
#     if x.all()== zero_list.all() or y.all() == zero_list.all():
#         return float(1) if x == y else float(0)
#     res = np.array([[x[i] * y[i], x[i] * x[i], y[i] * y[i]] for i in range(len(x))])
#     cos = sum(res[:, 0]) / (np.sqrt(sum(res[:, 1])) * np.sqrt(sum(res[:, 2])))
#     return 0.5 * cos + 0.5 if norm else cos  # 归一化到[0, 1]区间内

def cosine_similarity(x,y):
    num = x.dot(y.T)
    denom = np.linalg.norm(x) * np.linalg.norm(y)
    return num / denom


# 0变1不变
# 第二步速度变换
# 用于计算位置相减的操作    速度变换中的(G-Y)    相等时为1，不等时为0
def andPosLess(X1, X2):
    X = []
    for x1, x2 in zip(X1, X2):
        if x1 == x2:  # 值相等时保留
            X.append(1)
        else:  # 不相等时则需要改变
            X.append(0)
    return X


# 用于计算参数与位置相减结果相乘的结果   序列(未经过分区的），概率参数，本身的参数
# 参数大于等于随机数，不变    速度变换中的c1(G-Y)   select_change就是c1,c2等等       #返回1，0序列
def andPlus(X1, select_change):
    X = []
    r = np.random.rand(len(X1)).tolist()  # 随机数
    for x1, x2 in zip(r, X1):
        if x1 > select_change:
            X.append(1 - x2)
        else:
            X.append(x2)

    return X


# 用于计算速度变化中的＋操作 v = wv+c1(G-Y)+c2(P-Y)
def andOr(X1, X2, X3):
    velocity = []
    r = np.random.rand(len(X1)).tolist()
    for ran, x1, x2, x3 in zip(r, X1, X2, X3):
        if ran < 0.5:
            if x1 == 0 or x2 == 0 or x3 == 0:
                velocity.append(0)
            else:
                velocity.append(1)
        else:
            if x1 == 1 or x2 == 1 or x3 == 1:
                velocity.append(1)
            else:
                velocity.append(0)
    return velocity


# 第三步位置交换

# 速度相减的公式   数值相同，保持原数值，不同，有概率的变换
def andVelLess(V1, V2):
    velocity = []
    r = np.random.rand(len(V1)).tolist()
    for ran, v1, v2 in zip(r, V1, V2):
        if v1 == v2:
            velocity.append(v1)
        else:
            if ran < 0.5:
                velocity.append(0)
            else:
                velocity.append(1)
    return velocity


# 进行位置变换   通过速度和位置  1变0不变   返回的是新位置
def changePos(X1, V1, G,Apore_embedding):
    pos = []  # 用来更新位置的
    # X1_old_label = X1.copy()
    not_stab = []
    for v in range(len(V1)):
        if V1[v]==1:
            not_stab.append(v)
    for i in not_stab:  #i就是节点序号
        X1_old_label = X1.copy()
        X1_old_new = finall_objective(partition(X1_old_label), G)  # 求当前的适应度值
        neibors = list(G.adj[i])  # 求邻居  返回的是结点序号
        similarity = []
        similarity_index = []
        neiborsNotLable = []
        neiborsNot = []
        for j in range(len(neibors)):
            if X1[i] != X1[neibors[j]]:
                neiborsNotLable.append(X1[neibors[j]])  #记录的是标签值
                neiborsNot.append(neibors[j])  #记录下标
        # neiborsNotLable = np.unique(neiborsNotLable).tolist()  # 去重升序
        if len(neiborsNotLable) > 0:
            for j in range(len(neiborsNot)):
                t = random.randint(0,3)
                similarity.append(cosine_similarity(Apore_embedding[t][i],Apore_embedding[t][j]))  #计算相似度
            max_value = max(similarity)  #可能不唯一
            # max_label = similarity.index(max_value)
            for p in range(len(similarity)):
                if similarity[p] == max_value:
                    similarity_index.append(p)  #记录similarity的序号
            if len(similarity_index)>1:  #说明相似度指相等的不唯一
                sim = []  #记录相似度相等值的标签
                for p in similarity_index:
                    sim.append(neiborsNotLable[p])
                sim=np.unique(sim).tolist()
                m = collections.defaultdict(int)
                for p in X1:
                    if p in sim:
                        m[p] +=1
                max_v = max(m.values())
                more = [item[0] for item in m.items() if item[1] == max_v]
                X1[i] =random.choice(more)
                # if X1_old_new > finall_objective(partition(X1),G):
                #     X1 = X1_old_label.copy()   #小的话就不变
            elif len(similarity_index)==1:
                X1[i] = neiborsNotLable[similarity_index[0]]
                if X1_old_new > finall_objective(partition(X1), G):
                    X1 = X1_old_label.copy()



    # X1_old_label = X1.copy()
    # neibors = list(G.adj[i]) #求邻居
    # neiborsNotLable = []  # 用来记录i结点邻居中和i结点标签不同的标签
    # for neibor_index in neibors:

    # X1_old_new = finall_objective(partition(X1_old_label),G)  #求当前的适应度值
    # X1_old_new_obj = []
    # for j in range(len(neibors)):
    #     if X1[i] != X1[neibors[j]]:
    #         neiborsNotLable.append(X1[neibors[j]])  #记录的是标签值
    # if len(neiborsNotLable) > 0:
    #     neiborsNotLable = np.unique(neiborsNotLable).tolist()   #可能会出现空的情况
    #     for j in range(len(neiborsNotLable)): #经过循环后，X1_old_new_obj就充满了目标函数值
    #         X1[i] = neiborsNotLable[j]
    #         X1_old_new_obj.append(finall_objective(partition(X1),G))
    #     max_value = max(X1_old_new_obj)   #求使得目标值最大的
    #     max_label = X1_old_new_obj.index(max_value) #求下标
    #     if max_value > X1_old_new:
    #         X1[i] = neiborsNotLable[max_label]    #大的话就改变
    #     else:
    #         X1 = X1_old_label.copy()       #否则找原来的
        # X1_old_new = finall_objective(partition(X1_old_label), G)
        # X1_old_new_obj = []
        # max_labels = get_max_neighbor_label(G, X1, i)  #返回的是标签值
        # if len(max_labels) > 0:  # 如果不是空列表的话
        #     max_labels =np.unique(max_labels).tolist()
        #     for j in range(len(max_labels)): #经过循环后，X1_old_new_obj就充满了目标函数值
        #         X1[i] = max_labels[j]
        #         X1_old_new_obj.append(finall_objective(partition(X1),G))
        #     max_value = max(X1_old_new_obj)  # 求使得目标值最大的
        #     max_label = X1_old_new_obj.index(max_value)  # 求下标
        #     if max_value > X1_old_new:
        #         X1[i] = max_labels[max_label]  # 大的话就改变
        #     else:
        #         X1 = X1_old_label.copy()  # 否则找原来的
            # ind = np.random.randint(0, len(max_labels))
            # X1[i] = ind
    return X1

        # if len(max_labels) != 0:  # 如果不是空列表的话
        #     ind = np.random.randint(0, len(max_labels))  # 多个相同的情况下随机取一个   左闭右开
        #     pos.append(max_labels[ind])



# 第一步的公式
# 上半部分
# X2就是P-G  X3就是G-Y  乘以参数过的
# def andoR(X2, X3):
#     X = []
#     r = np.random.rand(len(X2)).tolist()
#     for ran, x2, x3 in zip(r, X2, X3):
#         if ran < 0.5:
#             if x2 == 0 or x3 == 0:
#                 X.append(0)
#             else:
#                 X.append(1)
#         else:
#             if x2 == 1 or x3 == 1:
#                 X.append(1)
#             else:
#                 X.append(0)
#     return X



# 改后下半部分
#改后下半部分         根据邻居变
def randChange(X1,X2,X3,X4,iso_list,G):  #要加回滚但未加
    not_stab = []  #记录不稳定的节点序号
    for i in range(len(X2)):
        if (X2[i] !=X3[i]) or (X2[i] != X4[i]):#三个最优个体并不全是相同的情况
            not_stab.append(i)
    for i in not_stab:  #去除孤立节点的情况
        if i in iso_list:#[25，4]
            not_stab.remove(i)
    for i in range(len(X1)):  #簇号让其固定
        if i not in not_stab:
            X1[i] = X2[i]
    for i in not_stab:  #i是记录下标
        max_index = np.max(X1) #获取当前个体的最大标签
        #得到i结点的邻居
        neibors = list(G.adj[i])
        # 用来记录i结点邻居中和i结点标签不同的标签
        neiborsNotLable = []
        for j in range(len(neibors)):
            if X1[i] != X1[neibors[j]]:
                neiborsNotLable.append(X1[neibors[j]])
        if len(neiborsNotLable)!=0:  #有邻居的情况
            neiborsNotLable.append(max_index + 1)
            neiborsNotLable = np.unique(neiborsNotLable).tolist()
            X1[i] = np.random.choice(neiborsNotLable)
    return X1
# def randChange(X1, mu, u, X2, X3, X4, X5, iso_list):
#     X = []
#     not_stab = []  # 记录不稳定的节点序号
#     max_index = np.max(X1)
#     for i in range(len(X2)):
#         if (X2[i] != X3[i]) or (X2[i] != X4[i]):  # 三个最优个体并不全是相同的情况
#             not_stab.append(i)
#         elif X2[i] == X5[i]:  # 全部相同但是和最差的是一样的
#             not_stab.append(i)
#     for i in not_stab:  # 去除孤立节点的情况
#         if i in iso_list:  # [25，4]
#             not_stab.remove(i)
#
#     # min_index = np.min(X1)
#     # u1 = np.ceil(u / 2)
#     # l1 = -u1
#     # y_ = np.around(mu*(np.around((u1-l1)*np.random.random_sample(),3)+min_index))* np.sign(np.random.random_sample() - 0.50)
#     # for i in not_stab:
#     #     X1[i] = X1[i]+y_
#     #     if X1[i]<l1:
#     #        X1[i] = l1
#     #     elif X1[i]>u1:
#     #         X1[i] = u1
#     # new_min_index = np.min(X1)
#     # for i in range(len(X1)):
#     #     X.append(X1[i] + abs(new_min_index))#变回全是正值的情况
#     return X


# 关于速度变换位置
# def changPosByVel(V1, V2, a):
#     r = np.random.rand(len(V1)).tolist()
#     V3 = (V1 + V2) * (V2 - V1)
#     V4 = []  # 用来存储V3的正数化的
#     V5 = []  # 用来存储最高的速度结果
#     for r1, v3, v1, v2 in zip(r, V3, V1, V2):
#         if v3 < 0:  # 只在负数的时候进行变化
#             if r1 < 0.5:
#                 if v1 == 0 or v2 == 0:
#                     V4.append(0)
#                 else:
#                     V4.append(1)
#             else:
#                 if v1 == 1 or v2 == 1:
#                     V4.append(1)
#                 else:
#                     V4.append(0)
#         else:  # 1或者0直接添加
#             V4.append(v3)
#     a = 1 / (2 * a)  # (0.5,1] 大多数都接近0.5
#     for r1, v4 in zip(r, V4):  # 让速度变化的概率多一些
#         if r1 < a:
#             V5.append(1 - v4)
#         else:
#             V5.append(v4)
#     return V5


# 更新速度中P-X,G-X
def xOr(X1, X2):
    X_i = []
    for x1, x2 in zip(X1, X2):
        if x1 == x2:
            X_i.append(0)
        else:
            X_i.append(1)
    X = np.array(X_i)
    return X


# 更新速度
def update_velo(V1, Pbest, X, Gbest, c1, c2, omega):  # 这里的omega是已经定义好的      1变0不变  c1,c2就是p1,p2
    V = []
    r = np.random.rand(len(X)).tolist()  # 随机数
    r_1 = np.random.rand(len(X)).tolist()
    Pbest_x_new = []
    Gbest_x_new = []
    r = np.random.rand(len(V1)).tolist()
    Pbest_x = xOr(Pbest, X)
    Gbest_x = xOr(Gbest, X)
    for x1, x2, r1, r2 in zip(Pbest_x, Gbest_x, r, r_1):
        Pbest_x_new.append(c1 * r1 * x1)
        Gbest_x_new.append(c2 * r2 * x2)
    for i in range(len(V1)):
        V_new = omega * V1[i] + Pbest_x_new[i] + Gbest_x_new[i]
        if 1 / (1 + exp(-V_new)) > np.random.random_sample():
            V.append(1)
        else:
            V.append(0)
    V_new_new = np.array(V)
    return V_new_new

#分段函数上半部分
def changePos_1(X1, V1, G, iso_list):
    # 用来更新位置的
    not_stab = []
    for i in iso_list:
        V1[i] = 0
    for i in range(len(V1)):
        if V1[i] == 1:
            not_stab.append(i)
    pos = edgeNodeMutation(X1, G, not_stab)  # 都有回滚操作
    return pos

def andPlus_1(X,Pbest,Gbest,p1,p2):   #分段函数上半部分后面一部分  返回0-1序列
    r_1 = np.random.rand(len(X)).tolist()
    r_2 = np.random.rand(len(X)).tolist()
    plus = []
    Pbest_Gbest_new = []
    Gbest_x_new = []
    Pbest_Gbest = xOr(Pbest, Gbest)
    Gbest_x = xOr(Gbest, X)
    for x1,x2,r1,r2 in zip(Pbest_Gbest,Gbest_x,r_1,r_2):
        Pbest_Gbest_new.append(p1 * r1 * x1)
        Gbest_x_new.append(p2 * r2 * x2)
    for i in range(len(X)):
        X_new = Pbest_Gbest_new[i] + Gbest_x_new[i]
        if 1 / (1 + exp(-X_new)) > np.random.random_sample():
            plus.append(1)
        else:
            plus.append(0)
    plus_new = np.array(plus)
    return plus_new



if __name__ == '__main__':
    # X = [0, 3, 5, 9, 8, 7, 7, 4, 6, 5, 5, 6]
    # miu = 0.85
    # u = 11
    # X1 =
    # print(X1)
    # V1 = np.array([1,0,0,1,1,1,0,0,1,0,1])
    # V2 = np.array([1, 0, 1, 1, 0, 1, 1, 0, 0, 0, 1])
    # for t in range(1, 1001):
    #     a = 1 - exp(-log(t + 1))
    #     print(changPosByVel(V1,V2,a))
    print(0)
