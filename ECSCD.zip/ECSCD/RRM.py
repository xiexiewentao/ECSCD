import random
import numpy as np
'''
去冗余策略思想：
例如：
[2,3,5,6,5,6]=>[0,1,2,3,2,3]
'''
def RRM(X):#传进来的是一行一行X
    dim = len(X)
    label = 0
    newX = np.ones(dim) * float("inf")
    for j in range(dim):
        if (newX[j] == float("inf")):
            newX[j] = label
            for k in range(j + 1, dim):
                if (X[j] == X[k]):
                    newX[k] = newX[j]
            label += 1

    return newX

if __name__ == '__main__':
    X = [1, 2, 2, 2, 1, 2, 1, 1, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 1, 2, 2, 2, 2, 2, 2, 2, 2, 2, 1, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 1, 2, 1, 2, 2, 1, 2, 2, 2, 2, 2, 2, 2, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 1, 3, 3, 3, 3, 3, 3, 1, 2, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 1, 1]
    print(RRM(X))
