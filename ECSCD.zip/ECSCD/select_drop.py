def clearDup():

    return