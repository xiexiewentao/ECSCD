import numpy as np
from math import exp
import matrix_to_graph as m2g
from load_graph import load_graph_noRealLable
# G.has_edge是考虑方向的   返回簇内的连接
def get_Intra_edge_num(cluster, G):
    intra_edge_num = 0
    for i in cluster:
        for j in cluster:
            if G.has_edge(int(i), int(j)):
                intra_edge_num += 1

    return intra_edge_num


# 只考虑不在同一社区的边数
def get_Inter_edge_num(cluster, G, mutated):
    inter_edge_num = 0
    for i in cluster:
        for j in G.nodes:
            if j not in cluster:
                if (G.has_edge(i, j)) | G.has_edge(j, i):
                    inter_edge_num += 1
                    if i not in mutated:
                        mutated.append(i)
                    if j not in mutated:
                        mutated.append(j)
    return inter_edge_num


def MFcalculation(cluster, G, mutated):
    i = get_Intra_edge_num(cluster, G)
    j = get_Inter_edge_num(cluster, G, mutated)
    if i == 0:
        MF = 0
    else:
        MF = i / (i + j / 2)
    return MF


# MQ metrics  max
def TurboMQ(X, G):  # 一个分区好的个体，G
    cluster_num = len(X)
    MF = []
    mutated = []

    for i in range(cluster_num):
        clus = X[i]
        MF_value = MFcalculation(clus, G, mutated)
        MF.append(MF_value)

    MQ = sum(MF)
    return MQ


# 按边进行计算所有节点的MQ
def NewTurboMQ(X, XX, G):  # 每一行， 分簇后的结果[0,0,0,1,1,2,2]=>[[0,1,2],[3,4],[5,6]]，图

    n = len(G.nodes)
    cluster_num = len(XX)  # 几个簇
    # numClus为每个社区的长度   ?每个
    numClus = np.zeros([cluster_num])  # 不就是一个0.0.的数组嘛，为啥是长度呢    eg.[0. 0.]
    mutated = []
    nodeClus = np.zeros([n, cluster_num])  # (节点行，簇列)
    interNei = np.zeros([cluster_num])
    intraNei = np.zeros([cluster_num])

    MQ = 0
    for c in G.edges:
        # 获取边结点
        c0 = c[0]
        c1 = c[1]
        # 获取边结点所在社区标签
        x0 = int(X[c0])
        x1 = int(X[c1])

        if x0 != x1:
            interNei[x0] += 1
            interNei[x1] += 1
        else:
            intraNei[x0] += 1  # 同一社区间的边
        # 遍历标记,nodeClus记录每个结点有多少条边,以及该结点属于哪一个社区
        nodeClus[c0, x0] += 1
        nodeClus[c1, x1] += 1
    for i in range(cluster_num):
        numClus[i] = len(XX[i])
        if (intraNei[i] == 0) and (interNei[i] == 0):
            MQ += 0
        else:
            MQ += (intraNei[i] / (intraNei[i] + interNei[i] / 2))

    return MQ


def instabcalculation(clus, G):  # clus 为分好的类（一维数组）

    Ca = 0
    Ce = 0
    # print(clus) [0, 1, 3] [2, 4, 5, 6, 7]
    for i in clus:
        for j in list(G.predecessors(i)):
            if j not in clus:
                Ca += 1
        for k in list(G.successors(i)):
            if k not in clus:
                Ce += 1

    if (Ca + Ce) == 0:
        instab = 0
    else:
        instab = Ce / (Ca + Ce)

    return instab


# Global Stability   max
def get_Instability(X, G):  # 一行一行的传,传入的是已经分好区的个体
    cluster_num = len(X)
    instab = []
    count = 0
    for i in range(cluster_num):
        clus = X[i]
        instab_value = instabcalculation(clus, G)
        instab.append(instab_value)

    for i in instab:
        if i < 0.5:  # 阈值
            count += 1
    instability = count / len(instab)

    return instability


# 孤立结点数  (最小化)

def isolatedNodeNum(X):  # 一行一行的传,传入的是已经分好区的个体
    num = 0
    for i in range(len(X)):
        if len(X[i]) == 1:
            num += 1
    return num


# 集群中最大模块数与最小模块数之差 (最小化)
def maxDiffMin(X):  # 一行一行的传,传入的是已经分好区的个体
    max = len(X[0])
    min = len(X[0])
    for i in range(1, len(X)):
        if max < len(X[i]):
            max = len(X[i])
        if min > len(X[i]):
            min = len(X[i])
    diff = max - min
    return diff


def objFunFirst1(X, G):
    fir = TurboMQ(X, G)   #max
       #max
    # thi = exp(-(maxDiffMin(X) + isolatedNodeNum(X)))    #e^-x
    # objfun = (fir ** 0.45) * (sec ** 0.45) * (thi ** 0.1)
    return fir
def objFunFirst2(X, G):
    sec = get_Instability(X, G)
    return sec


#计算Q值
def cal_Q(comm, G):
    # 边的个数
    edges = G.edges()
    m = len(edges)

    # 每个节点的度
    du = G.degree()

    # 通过节点对（同一个社区内的节点对）计算
    ret = 0.0
    for c in comm:
        for x in c:
            for y in c:
                # 边都是前小后大的
                # 不能交换x，y，因为都是循环变量
                if x <= y:
                    if (x, y) in edges:
                        aij = 1.0
                    else:
                        aij = 0.0

                else:
                    if (y, x) in edges:
                        aij = 1.0
                    else:
                        aij = 0
                tmp = aij - du[x] * du[y] * 1.0 / (2 * m)
                ret = ret + tmp

    ret = ret * 1.0 / (2 * m)

    return ret

if __name__ == '__main__':
    G = load_graph_noRealLable("dataset/real networks/LFR/LFR_MU/EDGE_LIST/0.8.txt")
    dim = len(G.nodes)
