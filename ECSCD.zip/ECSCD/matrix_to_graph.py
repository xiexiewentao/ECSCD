import numpy as np
import networkx as nx
from collections import Counter

def load_graph(path):

    m = np.loadtxt(path, dtype=int)
    G = nx.from_numpy_matrix(m, False, nx.DiGraph)   #从 numpy 矩阵返回一个图   numpy 矩阵被解释为图的邻接矩阵
    #nx.write_edgelist(G, 'db_graph.txt', data=False)

    return G

if __name__ == '__main__':


    G = load_graph("dataset/Mozilla Firefox_matrix/accessible.txt")
    indegree = []
    outdegree = []
    degree = []
    for i in G.nodes:
        if list(G.predecessors(i)) == []:
            indegree.append(i)
        if list(G.successors(i)) == []:
            outdegree.append(i)
        degree.append(G.degree(i))
    dict = Counter(degree)
    print(dict)
    print(len(dict))
    print("indegree num", len(indegree))
    print("outdegree num",len(outdegree))

    print(list(G.predecessors(40)))
    print(list(G.successors(40)))