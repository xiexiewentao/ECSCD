import numpy as np
import matrix_to_graph as m2g
#基于密度排序的
def get_max_weight_node(G):
    n = len(G.nodes)
    nod = []
    sumDegree = np.zeros([n])
    weight = np.zeros([n])
    froze = []
    unfroze = []
    du = G.degree()

    for i in range(n):
        if du(i) != 0:
            unfroze.append(i)  # print("i",i,neibors)
        else:
            froze.append(i)
    for i in G.nodes:
        nod.append(i)
        neibors = list(G.adj[i])  # 找到i的所有邻居
        sumDegree[i] = 0
        if len(neibors) != 0:
            for neibor in neibors:
                sumDegree[i] = sumDegree[i] + du(neibor)

    for i in G.nodes:
        neibors = list(G.adj[i])  # 找到i的所有邻居
        k1 = 0
        if len(neibors) != 0:
            for neibor in neibors:
                k1 = k1 + sumDegree[neibor]
            weight[i] = sumDegree[i] / k1

    index1 = np.argsort(weight, axis=0)[::-1]
    return index1
if __name__ =="__main__":
    G = m2g.load_graph("dataset/Mozilla Firefox_matrix/browser.txt")  # 45,45,4
    print(get_max_weight_node(G))