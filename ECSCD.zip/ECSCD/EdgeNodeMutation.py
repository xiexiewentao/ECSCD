#这里定义边缘结点为他的邻居的标签和他的标签不一样则称其为边缘节点
#大部分概率下边缘节点可以随机突变为他邻居的标签或者是一个新标签
#小部分概率下边缘结点和边缘结点标签相同的邻居突变为一个该边缘结点邻居的标签或者是一个新标签

import numpy as np
import networkx
from objectiveFunction import objFunFirst1,objFunFirst2
from partition import partition
from evo_objection import *

def edgeNodeMutation(X1, G,not_stab):  #就按邻居来变，变边界节点或者它所属的簇号
    for i in range(len(X1)):
        if i in not_stab:
            old_x = X1.copy()  #只是作为回滚的
            #max_lable = max(X1)  #获取当前个体的最大标签
            # 得到i结点的邻居
            neibors = list(G.adj[i])
            # 用来记录i结点邻居中和i结点标签不同的标签
            neiborsNotLable = []
            for j in range(len(neibors)):
                if X1[i] != X1[neibors[j]]:
                    neiborsNotLable.append(X1[neibors[j]])
            #neiborsNotLable.append(max_lable + 1)
            neiborsNotLable = np.unique(neiborsNotLable).tolist()  # 去重升序
            #判断i结点邻居中是否有和i结点标签不同的标签
            if (len(neiborsNotLable)>0) or (len(neibors)==1): #i是边界点
                if len(neiborsNotLable) == 0:
                    new_x = old_x
                else:
                    if np.random.rand() > 0.03:
                        X1[i] = np.random.choice(neiborsNotLable)
                        if finall_objective(partition(X1), G) > finall_objective(partition(old_x), G):  # 如果finess变大则留下，否则舍去
                            new_x = X1.copy()
                        else:
                            X1 = old_x.copy() # 变异效率不好则回滚到原始状态
                            new_x = old_x.copy()
                    else:
                        lable_old = X1[i]
                        X1[i] = np.random.choice(neiborsNotLable)
                        for j in range(len(neibors)):
                            if X1[neibors[j]] == lable_old:
                                X1[neibors[j]] = X1[i]
                        new_x = X1.copy()
            else:
                new_x = old_x
    return new_x  #返回按照结点DPC密度值的排序序列